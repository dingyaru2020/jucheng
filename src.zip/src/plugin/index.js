import Vue from 'vue';
import { 
    Tab, 
    Tabs ,
    NavBar ,
    Icon ,
    Popup 
} from 'vant';

Vue.use(Tab);
Vue.use(Tabs);
Vue.use(NavBar);
Vue.use(Icon);
Vue.use(Popup);