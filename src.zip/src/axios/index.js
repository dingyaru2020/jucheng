//接口模块
// export {default as home} from './home'
export {default as theater} from './theater'
export {default as person} from './person'
export {default as show} from './show'
// import home from "./home"
// import theater from "./theater"
// import person from "./person"
// import show from "./show"

// export default {
//     home,
//     theater,
//     person,
//     show
// }