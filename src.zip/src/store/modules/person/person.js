// import { GET_USERINFO } from "../../mutationTypes";
// import axios from "../../../axios";
const state = {
  // userInfo: {
  //   nickName: "",
  //   photo: "",
  //   uid: "",
  //   isLogin: 0
  // },
  
};
const mutations = {
  // [GET_USERINFO](state, data) {
  //   state.userInfo.nickName = data.basic_info.nick_name;
  //   state.userInfo.photo = data.basic_info.photo;
  //   state.userInfo.uid = data.basic_info.uid;
  //   state.userInfo.isLogin = data.is_login
  // }
};
const actions = {
  // async getUserInfo({ commit }) {
  //   const result = await axios.get(
  //     "https://api.juooo.com/user/account/basicInfo?version=6.1.1&referer=2"
  //   );
  //   commit(GET_USERINFO, result.data);
  // }
};
const getters = {};
export default {
  state,
  mutations,
  actions,
  getters
};
