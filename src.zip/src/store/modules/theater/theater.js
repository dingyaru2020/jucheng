import {} from "../../mutationTypes"
//例：axios发请求需要写axios.home.reqindexData()
import * as axios from "@/axios"
const state={}
const mutations={}
const actions={}
const getters={}
export default {
    state,
    mutations,
    actions,
    getters
}