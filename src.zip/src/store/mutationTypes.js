//演出相关
export const GET_CATEGORY_LIST = "GET_CATEGORY_LIST"
export const GET_SHOW_LIST = "GET_SHOW_LIST"
export const GET_CITY_LIST = "GET_CITY_LIST"
export const GET_SHOW_INFO = "GET_SHOW_INFO"
export const GET_TICKET_LIST = "GET_TICKET_LIST"
//首页
export const GET_LIST = 'GET_LIST'
export const GET_DISCOUNT_LIST = 'GET_DISCOUNT_LIST'
export const GET_SHOW_SWIPER_LIST = 'GET_SHOW_SWIPER_LIST'
export const GET_HOT_SHOW_LIST = 'GET_HOT_SHOW_LIST'