<template>
  <div>票夹</div>
</template>

<script>
export default {
  name: 'Ticket',
}
</script>

<style lang="less" scoped>

</style>
